
<?php $__env->startSection('title', 'User'); ?>
<?php $__env->startSection('header', 'User'); ?>
<?php $__env->startSection('button-header'); ?>
<div class="section-header-button">
    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary">Add New</a>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-body">
        <p class="section-title">
          <p class="section-lead">
              You can manage all users, such as editing, deleting and more.
          </p>
      </p>
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div id="table-1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-striped dataTable no-footer" id="table-1" role="grid"
                                        aria-describedby="table-1_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width: 5%;"><center>No</center></th>
                                                <th class="sorting"style="width: 20%;">Name</th>
                                                <th class="sorting"style="width: 10%;">Username</th>
                                                
                                                <th class="sorting"style="width: 20%;">Alamat</th>
                                                <th class="sorting"style="width: 13%;">Tanggal Lahir</th>
                                                <th class="sorting"style="width: 10%;">Role</th>
                                                <th style="width: 15%;">
                                                    <center>Created at</center>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $daftar_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr role="row" class="even">
                                                <td>
                                                    <center>
                                                        <?php echo e(++$no + ($daftar_user->currentPage()-1) * $daftar_user->perPage()); ?>

                                                    </center>
                                                </td>
                                                <td><?php echo e($user->nama); ?>

                                                  <div class="table-links">
                                                    <a href="<?php echo e(route('user.edit', ['id'=>$user->id])); ?>">Edit</a>
                                                    <div class="bullet"></div>
                                                    <a href="<?php echo e(route('user.destroy', ['id'=>$user->id])); ?>" class="text-danger">Delete</a>
                                                  </div>
                                                </td>
                                                <td><?php echo e($user->username); ?></td>
                                                
                                                <td><?php echo e($user->alamat); ?></td>
                                                <td><?php echo e($user->tgl_lahir); ?></td>
                                                <td><?php echo e($user->role->nama); ?></td>

                                                <td class="text-right">
                                                    <center>
                                                        <?php echo e($user->created_at->format('d M Y, H:i')); ?>

                                                    </center>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/user/index.blade.php ENDPATH**/ ?>