
<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('header', 'Category'); ?>
<?php $__env->startSection('button-header'); ?>
<div class="section-header-button">
    <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary">Add New</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-body">
    <p class="section-title">
        <p class="section-lead">
            You can manage all categories, such as editing, deleting and more.
        </p>
    </p>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div id="table-1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-striped dataTable no-footer" id="table-1" role="grid"
                                        aria-describedby="table-1_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width: 10%;">
                                                    <center>No</center>
                                                </th>
                                                <th class="sorting"style="width: 75%;">Name</th>
                                                <th style="width: 15%;">
                                                    <center>Created at</center>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $daftar_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr role="row" class="even">
                                                <td>
                                                    <center>
                                                        <?php echo e(++$no + ($daftar_category->currentPage()-1) * $daftar_category->perPage()); ?>

                                                    </center>
                                                </td>
                                                <td><?php echo e($category->nama); ?><div class="table-links">
                                                    <a href="<?php echo e(route('category.edit', ['id'=>$category->id])); ?>">Edit</a>
                                                    <div class="bullet"></div>
                                                    <a href="<?php echo e(route('category.destroy', ['id'=>$category->id])); ?>" class="text-danger">Delete</a>
                                                  </div></td>

                                                <td class="text-right">
                                                    <center>
                                                        <?php echo e($category->created_at->format('d M Y, H:i')); ?>

                                                    </center>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/category/index.blade.php ENDPATH**/ ?>