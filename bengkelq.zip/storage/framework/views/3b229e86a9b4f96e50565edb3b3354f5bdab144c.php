<script type = "text/javascript" >
    $(document).ready(function () {
        <?php if($message = Session::get('sukses')): ?>
        iziToast.success({
            title: 'Hey',
            message: '<?php echo e($message); ?>',
            timeout: 5000,
            position: 'topRight',
            closeOnClick: true,
        });
        <?php elseif($message = Session::get('delete')): ?>
        iziToast.warning({
            title: 'Hey',
            message: '<?php echo e($message); ?>',
            timeout: 5000,
            position: 'topRight',
            closeOnClick: true,
        });
        <?php elseif($message = Session::get('update')): ?>
        iziToast.info({
            title: 'Hey',
            message: '<?php echo e($message); ?>',
            timeout: 5000,
            position: 'topRight',
            closeOnClick: true,
        });
        <?php elseif($message = Session::get('gagal')): ?>
        iziToast.warning({
            title: 'Oh no!!',
            message: '<?php echo e($message); ?>',
            timeout: 5000,
            position: 'topRight',
            closeOnClick: true,
        });
        <?php endif; ?>
    });
</script>
<?php /**PATH C:\laragon\www\bengkelq\resources\views/layouts/izitoast.blade.php ENDPATH**/ ?>