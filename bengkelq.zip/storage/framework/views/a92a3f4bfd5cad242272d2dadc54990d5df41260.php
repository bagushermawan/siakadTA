<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('header', 'Product'); ?>
<?php $__env->startSection('button-header'); ?>
<div class="section-header-button">
    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Add New</a>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-body">
        <p class="section-title">
          <p class="section-lead">
              You can manage all products, such as editing, deleting and more.
          </p>
      </p>
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div id="table-1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-striped dataTable no-footer" id="table-1" role="grid"
                                        aria-describedby="table-1_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width: 5%;"><center>No</center></th>
                                                <th class="sorting"style="width: 20%;">Nama</th>
                                                <th class="sorting"style="width: 10%;">Stock</th>
                                                <th class="sorting"style="width: 20%;">Price</th>
                                                <th class="sorting"style="width: 20%;">Category</th>
                                                <th style="width: 15%;"><center>Created at</center></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $daftar_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr role="row" class="even">
                                                <td>
                                                    <center>
                                                        <?php echo e(++$no + ($daftar_product->currentPage()-1) * $daftar_product->perPage()); ?>

                                                    </center>
                                                </td>
                                                <td><?php echo e($product->nama); ?>

                                                  <div class="table-links">
                                                    <a href="<?php echo e(route('product.edit', ['id'=>$product->id])); ?>">Edit</a>
                                                    <div class="bullet"></div>
                                                    <a href="<?php echo e(route('product.destroy', ['id'=>$product->id])); ?>" class="text-danger">Delete</a>
                                                  </div>
                                                </td>
                                                <td><?php echo e($product->stock); ?></td>
                                                <td>Rp <?php echo e($product->price); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $product->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="badge badge-primary"><?php echo e($c->nama); ?></div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td class="text-right"><center><?php echo e($product->created_at->format('d M Y, H:i')); ?></center></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/product/index.blade.php ENDPATH**/ ?>