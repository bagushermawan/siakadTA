
<?php $__env->startSection('title', 'Role'); ?>
<?php $__env->startSection('header', 'Role'); ?>
<?php $__env->startSection('button-header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-body">
    <div class="row">
        <div class="col-12 col-md-12">
            <div class="card">
                
                <div class="card-body">
                    
                    <form action="<?php echo e(route('category.update', ['id' => $category->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('put')); ?>

                        <div class="form-group">
                            <label>Edit Category:</label>
                            <input type="text" name="nama" class="form-control" value="<?php echo e($category->nama); ?>">
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-primary mr-1" type="submit">Update</button>
                            <button class="btn btn-secondary" type="reset">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/category/edit.blade.php ENDPATH**/ ?>