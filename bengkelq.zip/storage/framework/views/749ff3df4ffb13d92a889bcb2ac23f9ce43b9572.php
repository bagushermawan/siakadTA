<div class="main-sidebar">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="<?php echo e(route('/')); ?>">Bengkelq Admin</a>
          </div>
          <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('/')); ?>">Bengs</a>
          </div>
          <ul class="sidebar-menu">
              <li class="menu-header">Dashboard</li>
              <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-fire"></i><span>Dashboard</span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="index-0.html">General Dashboard</a></li>
                  <li><a class="nav-link" href="index.html">Ecommerce Dashboard</a></li>
                </ul>
              </li>
              <li class="menu-header">Pages</li>
              <li class="nav-item dropdown active">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-columns"></i> <span>Menu</span></a>
                <ul class="dropdown-menu">
                  <li class="<?php echo e(request()->is('user*') ? 'active' : ''); ?>"><a class="nav-link<?php echo e(request()->is('user*') ? ' beep beep-sidebar' : ''); ?>" href="<?php echo e(route('user')); ?>">User</a></li>
                  <li class="<?php echo e(request()->is('role*') ? 'active' : ''); ?>"><a class="nav-link<?php echo e(request()->is('role*') ? ' beep beep-sidebar' : ''); ?>" href="<?php echo e(route('role')); ?>">Role</a></li>
                  <li class="<?php echo e(request()->is('category*') ? 'active' : ''); ?>"><a class="nav-link<?php echo e(request()->is('category*') ? ' beep beep-sidebar' : ''); ?>" href="<?php echo e(route('category')); ?>">Category</a></li>
                  <li class="<?php echo e(request()->is('product*') ? 'active' : ''); ?>"><a class="nav-link<?php echo e(request()->is('product*') ? ' beep beep-sidebar' : ''); ?>" href="<?php echo e(route('product')); ?>">Product</a></li>
                  <li class="<?php echo e(request()->is('complaint*') ? 'active' : ''); ?>"><a class="nav-link<?php echo e(request()->is('complaint*') ? ' beep beep-sidebar' : ''); ?>" href="<?php echo e(route('complaint')); ?>">Complaint</a></li>
                  <li class="<?php echo e(request()->is('transaction*') ? 'active' : ''); ?>"><a class="nav-link<?php echo e(request()->is('transaction*') ? ' beep beep-sidebar' : ''); ?>" href="<?php echo e(route('transaction')); ?>">Transactions</a></li>
                </ul>
              </li>
              <li><a class="nav-link" href="/crud"><i class="far fa-square"></i> <span>C R U D</span></a></li>
              
            </ul>

            <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
              <a href="https://demo.getstisla.com/" target="_blank" class="btn btn-primary btn-lg btn-block btn-icon-split">
                <i class="fas fa-rocket"></i> Documentation
              </a>
            </div>
        </aside>
      </div>
<?php /**PATH C:\laragon\www\bengkelq\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>