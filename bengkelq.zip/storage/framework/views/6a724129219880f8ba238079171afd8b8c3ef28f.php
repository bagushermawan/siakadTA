
<?php $__env->startSection('title', 'Transaction'); ?>
<?php $__env->startSection('header', 'Transaction'); ?>
<?php $__env->startSection('button-header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-body">
    <div class="row">
        <div class="col-12 col-md-12">
            <div class="card">
                
                <div class="card-body">
                    
                    <form action="<?php echo e(route('transaction.update', ['id' => $transaction->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('put')); ?>

                        <div class="form-group">
                            <label>Edit Kode:</label>
                            <input type="text" name="kode" disabled class="form-control" value="<?php echo e($transaction->kode); ?>">
                        </div>
                        <div class="form-group">
                            <label>Edit Nama:</label>
                            <input type="text" name="nama" class="form-control" value="<?php echo e($transaction->nama); ?>">
                        </div>
                        <div class="form-group">
                            <label>Edit Merek:</label>
                            <input type="text" name="merek" class="form-control" value="<?php echo e($transaction->merek); ?>">
                        </div>
                        <div class="form-group">
                            <label>Edit Plat Nomer:</label>
                            <input type="text" name="platnomer" class="form-control" value="<?php echo e($transaction->platnomer); ?>">
                        </div>
                        <div class="form-group">
                            <label>Edit Status:</label>
                            <label class="selectgroup-item">
                                <input type="radio" name="status" value="proses" class="selectgroup-input" checked="">
                                <span class="selectgroup-button selectgroup-button-icon"><i class="fas fa-sync"> Proses</i></span>
                            </label>
                            <label class="selectgroup-item">
                                <input type="radio" name="status" value="selesai" class="selectgroup-input" checked="">
                                <span class="selectgroup-button selectgroup-button-icon"><i class="fas fa-check"> Selesai</i></span>
                            </label>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-primary mr-1" type="submit">Update</button>
                            <button class="btn btn-secondary" type="reset">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/transaction/edit.blade.php ENDPATH**/ ?>