<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('header', 'Product'); ?>
<?php $__env->startSection('button-header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-body">
    <div class="row">
        <div class="col-12 col-md-12">
            <div class="card">
                
                <div class="card-body">
                    
                    <form action="<?php echo e(route('product.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Nama:</label>
                            <input type="text" name="nama" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Stock:</label>
                            <input type="number" name="stock" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Price:</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        Rp
                                    </div>
                                </div>
                                <input type="number" class="form-control currency" name="price">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Category:</label>
                            <select name="category_id[]" multiple class="categories" class="form-control">
                            </select>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-primary mr-1" type="submit">Submit</button>
                            <button class="btn btn-secondary" type="reset">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('page-script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cleave.js/1.6.0/cleave.min.js"></script>

    <script type="text/javascript">
        $(function () {
            $('.categories').select2({
                placeholder: 'Select Category',
                ajax: {
                    url: "<?php echo e(route('category.ajaxsearch')); ?>",
                    dataType: 'json',
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text: item.nama,
                                    id: item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });
        })
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/product/create.blade.php ENDPATH**/ ?>