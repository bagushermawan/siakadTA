
<?php $__env->startSection('title', 'Transaction'); ?>
<?php $__env->startSection('header', 'Transaction'); ?>
<?php $__env->startSection('button-header'); ?>
<div class="section-header-button">
    <a href="<?php echo e(route('transaction.create')); ?>" class="btn btn-primary">Add New</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-body">
    <p class="section-title">
        <p class="section-lead">
            You can manage all categories, such as editing, deleting and more.
        </p>
    </p>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <div id="table-1_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-striped dataTable no-footer" id="table-1" role="grid"
                                        aria-describedby="table-1_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width: 10%;">
                                                    <center>No</center>
                                                </th>
                                                <th class="sorting"style="width: 20%;">Kode</th>
                                                <th class="sorting"style="width: 10%;">Nama</th>
                                                <th class="sorting"style="width: 10%;">Merek</th>
                                                <th class="sorting"style="width: 10%;">Plat Nomer</th>
                                                <th class="sorting"style="width: 10%;">Status</th>
                                                <th style="width: 15%;">
                                                    <center>Created at</center>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $daftar_transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr role="row" class="even">
                                                <td>
                                                    <center>
                                                        <?php echo e(++$no + ($daftar_transaction->currentPage()-1) * $daftar_transaction->perPage()); ?>

                                                    </center>
                                                </td>
                                                <td><?php echo e($transaction->kode); ?><div class="table-links">
                                                    <a href="<?php echo e(route('transaction.edit', ['id'=>$transaction->id])); ?>">Edit</a>
                                                    <div class="bullet"></div>
                                                    <a href="<?php echo e(route('transaction.destroy', ['id'=>$transaction->id])); ?>" class="text-danger">Delete</a>
                                                  </div>
                                                </td>
                                                <td><?php echo e($transaction->nama); ?></td>
                                                <td><?php echo e($transaction->merek); ?></td>
                                                <td><?php echo e($transaction->platnomer); ?></td>
                                                <td><?php if($transaction->status=='proses'): ?><div class="badge badge-secondary">Proses</div> <?php else: ?> <div class="badge badge-success">Selesai</div> <?php endif; ?></td>

                                                <td class="text-right">
                                                    <center>
                                                        <?php echo e($transaction->created_at->format('d M Y, H:i')); ?>

                                                    </center>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bengkelq\resources\views/transaction/index.blade.php ENDPATH**/ ?>