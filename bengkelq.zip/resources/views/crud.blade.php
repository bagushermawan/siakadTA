@extends('layouts.master')
@section('title', 'CRUD')
@section('content')
    <div class="section-body">
        ini content crud
    </div>
@endsection