@extends('layouts.master')
@section('title', 'Home')
@section('content')
    <div class="section-body">
        ini content
    </div>
@endsection